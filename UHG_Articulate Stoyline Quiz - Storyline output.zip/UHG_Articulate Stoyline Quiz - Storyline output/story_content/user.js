function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6O3XRYa0xgL":
        Script1();
        break;
      case "5YgdgTzAuaB":
        Script2();
        break;
      case "5ntGSUrtegl":
        Script3();
        break;
      case "6gy6UoMMJ5v":
        Script4();
        break;
      case "6LSMzY5ciEz":
        Script5();
        break;
      case "6qzAexVzA6D":
        Script6();
        break;
      case "6Ruw15wZXu9":
        Script7();
        break;
      case "6cUq3hXH2SN":
        Script8();
        break;
      case "6WwqGVsWKIo":
        Script9();
        break;
      case "64jJRprld1B":
        Script10();
        break;
  }
}

function Script1()
{
  window.print();
}

function Script2()
{
  if correct_answers == 5:
    earnings += 4000
}

function Script3()
{
  if correct_answers == 5:
    earnings += 4000
}

function Script4()
{
  if correct_answers == 5:
    earnings += 4000
}

function Script5()
{
  window.print();
}

function Script6()
{
  window.print();
}

function Script7()
{
  window.print();
}

function Script8()
{
  window.print();
}

function Script9()
{
  window.print();
}

function Script10()
{
  window.print();
}

